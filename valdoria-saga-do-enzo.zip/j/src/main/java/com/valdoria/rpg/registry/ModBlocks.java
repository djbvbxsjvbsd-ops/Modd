package com.valdoria.rpg.registry;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.block.PortalNiveriaBlock;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, ValdoriaMod.MODID);
    public static final RegistryObject<Block> PORTAL_NIVERIA = BLOCKS.register("portal_niveria",
            () -> new PortalNiveriaBlock(BlockBehaviour.Properties.of()
                    .strength(-1.0F, 3600000.0F).lightLevel(s -> 15).noCollission().sound(SoundType.GLASS)));
}
