// [SyncQuestTargetPacket.java] — Sincroniza alvo da quest atual para ESP no cliente
package com.valdoria.rpg.network;

import com.valdoria.rpg.client.ClientData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public class SyncQuestTargetPacket {
    /** 0=nenhum, 1=KILL (entidade), 2=HAVE (item no chão), 3=outro (FLAG/DIM/FACTION) */
    public final int type;
    public final String target;   // resource location do alvo (ex: "minecraft:zombie")
    public final int questId;     // número da quest atual (para cor do ato)

    public SyncQuestTargetPacket(int type, String target, int questId) {
        this.type = type;
        this.target = target;
        this.questId = questId;
    }

    public static void encode(SyncQuestTargetPacket p, FriendlyByteBuf buf) {
        buf.writeInt(p.type);
        buf.writeUtf(p.target, 256);
        buf.writeInt(p.questId);
    }

    public static SyncQuestTargetPacket decode(FriendlyByteBuf buf) {
        return new SyncQuestTargetPacket(buf.readInt(), buf.readUtf(256), buf.readInt());
    }

    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientData.updateQuestTarget(type, target, questId));
    }
}
