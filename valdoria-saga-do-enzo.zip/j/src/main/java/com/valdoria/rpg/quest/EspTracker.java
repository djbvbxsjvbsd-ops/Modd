package com.valdoria.rpg.quest;

import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.network.SyncEspPacket;
import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Calcula no servidor onde estão os alvos da missão atual (mobs, bosses, itens no chão, locais). */
public final class EspTracker {
    private EspTracker() {}

    private static final Map<String, String> BOSS = Map.of(
            "malachar_dead", "valdorianrpg:malachar",
            "guardiao_glacial_dead", "valdorianrpg:guardiao_glacial",
            "ultimo_guardiao_dead", "valdorianrpg:guardiao_glacial",
            "senhor_gelo_dead", "valdorianrpg:senhor_gelo",
            "dragao_gelo_dead", "valdorianrpg:dragao_gelo",
            "enzo_glacial_dead", "valdorianrpg:enzo_glacial");

    /** Locais de Nivéria {x,y,z}. */
    private static final Map<String, int[]> LOCAL = Map.of(
            "vila_nevada_found", new int[]{80, 16, 0},
            "templo_glacial_found", new int[]{-120, 16, 60},
            "livro_templo_found", new int[]{-120, 16, 60},
            "profecia_niveria_read", new int[]{-120, 16, 60},
            "cidade_niveria_found", new int[]{0, 16, 200},
            "castelo_enzo_glacial_entered", new int[]{0, 16, 200},
            "arena_final_reached", new int[]{0, 37, 218});

    /** Onde procurar o boss se ele não estiver carregado. */
    private static final Map<String, int[]> BOSS_FALLBACK = Map.of(
            "senhor_gelo_dead", new int[]{-120, 16, 60},
            "dragao_gelo_dead", new int[]{0, 16, 200},
            "ultimo_guardiao_dead", new int[]{0, 16, 200},
            "enzo_glacial_dead", new int[]{0, 37, 218});

    /** Item de missão -> mob que o dropa. */
    private static final Map<String, String> DROP_FROM = Map.of(
            "minecraft:blaze_rod", "minecraft:blaze",
            "minecraft:ender_pearl", "minecraft:enderman",
            "minecraft:ender_eye", "minecraft:enderman",
            "minecraft:quartz", "minecraft:ghast");

    public record Result(int kind, String label, List<float[]> pts) {}

    public static void send(ServerPlayer sp) {
        Result r = compute(sp);
        ModNetwork.sendTo(sp, new SyncEspPacket(r.kind(), r.label(), r.pts()));
    }

    public static Result compute(ServerPlayer sp) {
        int qid = PlayerData.getCompleted(sp) + 1;
        if (qid > QuestData.size()) return new Result(0, "", List.of());
        Quest q = QuestData.get(qid);
        ServerLevel lvl = sp.serverLevel();
        boolean inNiv = lvl.dimension().equals(NiveriaDimension.NIVERIA);
        List<float[]> pts = new ArrayList<>();
        int kind = 0;
        String label = q.title();
        boolean niveriaTask = false;

        switch (q.type()) {
            case KILL -> {
                kind = 1;
                entities(sp, q.target(), pts);
                niveriaTask = q.target().startsWith("valdorianrpg:");
            }
            case HAVE -> {
                kind = 2;
                items(sp, q.target(), pts);
                String src = DROP_FROM.get(q.target());
                if (src != null) { entities(sp, src, pts); }
            }
            case FLAG -> {
                String boss = BOSS.get(q.target());
                if (boss != null) {
                    kind = 1;
                    entities(sp, boss, pts);
                    if (pts.isEmpty()) {
                        if (q.target().equals("malachar_dead") && lvl.dimension() == Level.OVERWORLD) {
                            BlockPos s = lvl.getSharedSpawnPos();
                            pts.add(new float[]{s.getX() + 0.5F, s.getY(), s.getZ() + 0.5F, 1.0F, 3.0F});
                            kind = 3;
                        } else {
                            int[] fb = BOSS_FALLBACK.get(q.target());
                            if (fb != null && inNiv) { pts.add(loc(fb)); kind = 3; }
                        }
                    }
                    niveriaTask = !q.target().equals("malachar_dead");
                } else if (LOCAL.containsKey(q.target())) {
                    kind = 3;
                    if (inNiv) pts.add(loc(LOCAL.get(q.target())));
                    niveriaTask = true;
                } else {
                    niveriaTask = q.id() >= 52;
                }
            }
            case DIM -> niveriaTask = q.target().equals("valdorianrpg:niveria");
            default -> { }
        }

        // quest de Nivéria estando fora: aponta o portal no spawn do Overworld
        if (niveriaTask && !inNiv && lvl.dimension() == Level.OVERWORLD && pts.isEmpty()) {
            BlockPos s = lvl.getSharedSpawnPos();
            pts.add(new float[]{s.getX() + 0.5F, s.getY(), s.getZ() + 0.5F, 1.0F, 3.0F});
            kind = 4;
            label = "Portal de Nivéria";
        }
        return new Result(kind, label, pts);
    }

    private static float[] loc(int[] c) { return new float[]{c[0] + 0.5F, c[1], c[2] + 0.5F, 1.0F, 3.0F}; }

    private static void entities(ServerPlayer sp, String id, List<float[]> out) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) return;
        EntityType<?> t = BuiltInRegistries.ENTITY_TYPE.getOptional(rl).orElse(null);
        if (t == null) return;
        List<Entity> found = new ArrayList<>();
        for (Entity e : sp.serverLevel().getAllEntities()) if (e.getType() == t && e.isAlive()) found.add(e);
        found.sort(Comparator.comparingDouble(e -> e.distanceToSqr(sp)));
        for (int i = 0; i < Math.min(found.size(), 12); i++) {
            Entity e = found.get(i);
            out.add(new float[]{(float) e.getX(), (float) e.getY(), (float) e.getZ(), e.getBbWidth(), e.getBbHeight()});
        }
    }

    private static void items(ServerPlayer sp, String id, List<float[]> out) {
        List<ItemEntity> found = new ArrayList<>();
        for (Entity e : sp.serverLevel().getAllEntities()) {
            if (e instanceof ItemEntity ie && !ie.getItem().isEmpty()
                    && id.equals(BuiltInRegistries.ITEM.getKey(ie.getItem().getItem()).toString())) found.add(ie);
        }
        found.sort(Comparator.comparingDouble(e -> e.distanceToSqr(sp)));
        for (int i = 0; i < Math.min(found.size(), 12); i++) {
            ItemEntity e = found.get(i);
            out.add(new float[]{(float) e.getX(), (float) e.getY(), (float) e.getZ(), 0.6F, 0.6F});
        }
    }
}
