// [QuestEsp.java] — ESP do alvo da missão: mobs/bosses/itens/locais (dados do servidor) + blocos próximos
package com.valdoria.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class QuestEsp {
    private QuestEsp() {}

    /** Cor RGB por ato. */
    public static int[] actColor(int questId) {
        if (questId <= 10)  return new int[]{255, 215,   0};
        if (questId <= 20)  return new int[]{255, 200,  50};
        if (questId <= 30)  return new int[]{255,  60,  60};
        if (questId <= 40)  return new int[]{255,  80, 255};
        if (questId <= 50)  return new int[]{255, 255, 255};
        if (questId <= 60)  return new int[]{  0, 220, 255};
        if (questId <= 70)  return new int[]{ 50, 220,  50};
        if (questId <= 80)  return new int[]{ 60, 120, 255};
        if (questId <= 90)  return new int[]{180,   0, 255};
        return                     new int[]{255,  40,  40};
    }

    private static final Map<String, String[]> EXTRA = Map.of(
            "minecraft:diamond",    new String[]{"minecraft:diamond_ore", "minecraft:deepslate_diamond_ore"},
            "minecraft:iron_ingot", new String[]{"minecraft:iron_ore", "minecraft:deepslate_iron_ore"},
            "minecraft:gold_ingot", new String[]{"minecraft:gold_ore", "minecraft:deepslate_gold_ore", "minecraft:nether_gold_ore"},
            "minecraft:emerald",    new String[]{"minecraft:emerald_ore", "minecraft:deepslate_emerald_ore"},
            "minecraft:quartz",     new String[]{"minecraft:nether_quartz_ore"},
            "minecraft:cobblestone", new String[]{"minecraft:stone"});

    private static final List<BlockPos> HITS = new ArrayList<>();
    private static String scanTarget = "";
    private static long scanTick = -100;

    private static Set<Block> blocksFor(String id) {
        Set<Block> s = new HashSet<>();
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) return s;
        Block b = BuiltInRegistries.BLOCK.get(rl);
        if (b != Blocks.AIR && !id.startsWith("valdorianrpg:")) s.add(b);
        String[] ex = EXTRA.get(id);
        if (ex != null) for (String e : ex) s.add(BuiltInRegistries.BLOCK.get(new ResourceLocation(e)));
        s.remove(Blocks.AIR);
        return s;
    }

    private static void scanBlocks(Minecraft mc) {
        String tgt = ClientData.questTarget;
        long gt = mc.level.getGameTime();
        if (tgt.equals(scanTarget) && gt - scanTick < 10) return;
        scanTarget = tgt; scanTick = gt; HITS.clear();
        Set<Block> wanted = blocksFor(tgt);
        if (wanted.isEmpty()) return;
        BlockPos c = mc.player.blockPosition();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        List<BlockPos> tmp = new ArrayList<>();
        for (int dx = -16; dx <= 16; dx++) for (int dy = -12; dy <= 12; dy++) for (int dz = -16; dz <= 16; dz++) {
            mp.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
            if (wanted.contains(mc.level.getBlockState(mp).getBlock())) tmp.add(mp.immutable());
        }
        tmp.sort(Comparator.comparingDouble(p -> p.distSqr(c)));
        for (int i = 0; i < Math.min(40, tmp.size()); i++) HITS.add(tmp.get(i));
    }

    public static void render(PoseStack ps, MultiBufferSource buf) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        int[] rgb = ClientData.espKind == 4 ? new int[]{0, 220, 255} : actColor(ClientData.questId);
        float r = rgb[0] / 255f, g = rgb[1] / 255f, b = rgb[2] / 255f;
        float pulse = (float) (Math.sin(System.currentTimeMillis() * 0.005) * 0.25 + 0.65);
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        VertexConsumer vc = buf.getBuffer(EspRenderTypes.ESP_LINES);
        Matrix4f mat = ps.last().pose();

        // ---- alvos do servidor (mob/boss/item/local/portal) ----
        double bestD = Double.MAX_VALUE;
        float[] best = null;
        for (float[] p : ClientData.espPts) {
            double dx = p[0] - cam.x, dy = p[1] - cam.y, dz = p[2] - cam.z;
            double d2 = dx * dx + dy * dy + dz * dz;
            float hw = Math.max(p[3], 0.6F) / 2.0F;
            boolean place = ClientData.espKind == 3 || ClientData.espKind == 4;
            AABB bb = new AABB(dx - hw, dy, dz - hw, dx + hw, dy + Math.max(p[4], 0.6F), dz + hw);
            box(vc, mat, bb, r, g, b, 1.0F);
            box(vc, mat, bb.inflate(0.12), r, g, b, pulse);
            if (place) {   // feixe vertical visível de longe
                box(vc, mat, new AABB(dx - 0.5, dy, dz - 0.5, dx + 0.5, dy + 80, dz + 0.5), r, g, b, pulse);
            }
            if (d2 < bestD) { bestD = d2; best = p; }
        }
        // traço do centro da tela até o alvo mais próximo
        if (best != null) {
            Vector3f look = mc.gameRenderer.getMainCamera().getLookVector();
            line(vc, mat, look.x * 1.5F, look.y * 1.5F, look.z * 1.5F,
                    (float) (best[0] - cam.x), (float) (best[1] + best[4] / 2.0F - cam.y), (float) (best[2] - cam.z),
                    r, g, b, 0.9F);
        }

        // ---- blocos do item da missão (troncos, minérios, neve...) ----
        if (ClientData.questTargetType == 2) {
            scanBlocks(mc);
            for (BlockPos bp : HITS) {
                AABB bb = new AABB(bp).move(-cam.x, -cam.y, -cam.z).inflate(0.02);
                box(vc, mat, bb, r, g, b, 0.85F);
            }
        }
    }

    private static void box(VertexConsumer vc, Matrix4f mat, AABB bb, float r, float g, float b, float a) {
        float x0 = (float) bb.minX, y0 = (float) bb.minY, z0 = (float) bb.minZ;
        float x1 = (float) bb.maxX, y1 = (float) bb.maxY, z1 = (float) bb.maxZ;
        line(vc, mat, x0,y0,z0, x1,y0,z0, r,g,b,a); line(vc, mat, x1,y0,z0, x1,y0,z1, r,g,b,a);
        line(vc, mat, x1,y0,z1, x0,y0,z1, r,g,b,a); line(vc, mat, x0,y0,z1, x0,y0,z0, r,g,b,a);
        line(vc, mat, x0,y1,z0, x1,y1,z0, r,g,b,a); line(vc, mat, x1,y1,z0, x1,y1,z1, r,g,b,a);
        line(vc, mat, x1,y1,z1, x0,y1,z1, r,g,b,a); line(vc, mat, x0,y1,z1, x0,y1,z0, r,g,b,a);
        line(vc, mat, x0,y0,z0, x0,y1,z0, r,g,b,a); line(vc, mat, x1,y0,z0, x1,y1,z0, r,g,b,a);
        line(vc, mat, x1,y0,z1, x1,y1,z1, r,g,b,a); line(vc, mat, x0,y0,z1, x0,y1,z1, r,g,b,a);
    }

    private static void line(VertexConsumer vc, Matrix4f mat,
                             float x0, float y0, float z0, float x1, float y1, float z1,
                             float r, float g, float b, float a) {
        float nx = x1 - x0, ny = y1 - y0, nz = z1 - z0;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len == 0) { nx = 0; ny = 1; nz = 0; } else { nx /= len; ny /= len; nz /= len; }
        vc.vertex(mat, x0, y0, z0).color(r, g, b, a).normal(nx, ny, nz).endVertex();
        vc.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(nx, ny, nz).endVertex();
    }
}
