package com.valdoria.rpg.world;

import com.valdoria.rpg.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.phys.AABB;

/** Mantém mobs de gelo (textura de gelo) por perto do jogador dentro da sala de Nivéria. */
public final class NiveriaMobs {
    private NiveriaMobs() {}

    public static void tick(ServerPlayer sp) {
        if (!sp.level().dimension().equals(NiveriaDimension.NIVERIA)) return;
        ServerLevel lvl = sp.serverLevel();
        AABB box = sp.getBoundingBox().inflate(48.0D);
        if (lvl.getEntitiesOfClass(Monster.class, box).size() >= 14) return;
        int golems = lvl.getEntitiesOfClass(com.valdoria.rpg.entity.GuardiaoGlacial.class, box.inflate(16)).size();
        RandomSource r = lvl.random;
        for (int i = 0; i < 3; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0D, dist = 14.0D + r.nextDouble() * 24.0D;
            int x = (int) (sp.getX() + Math.cos(ang) * dist);
            int z = (int) (sp.getZ() + Math.sin(ang) * dist);
            if (Math.abs(x) > 480 || Math.abs(z) > 480) continue;
            BlockPos pos = new BlockPos(x, NiveriaChunkGenerator.SPAWN_Y, z);
            if (!lvl.hasChunkAt(pos)) continue;
            if (!lvl.getBlockState(pos).isAir() || !lvl.getBlockState(pos.above()).isAir()) continue;
            float roll = r.nextFloat();
            Mob m;
            if (roll < 0.55F) m = ModEntities.CRIATURA_CONGELADA.get().create(lvl);
            else if (roll < 0.90F || golems >= 3) m = ModEntities.ESQUELETO_CONGELADO.get().create(lvl);
            else m = ModEntities.GUARDIAO_GLACIAL.get().create(lvl);
            if (m == null) continue;
            m.moveTo(x + 0.5D, NiveriaChunkGenerator.SPAWN_Y, z + 0.5D, r.nextFloat() * 360.0F, 0.0F);
            m.finalizeSpawn(lvl, lvl.getCurrentDifficultyAt(pos), MobSpawnType.NATURAL, null, null);
            if (m instanceof Zombie z2) z2.setBaby(false);
            lvl.addFreshEntity(m);
        }
    }
}
