// [MapScreen.java] — Mapa tecnológico com Nivéria integrada
package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.client.KeyMappings;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

public class MapScreen extends Screen {
    private static final int SIZE = 200;
    private static final int BLOCKS_PER_PX = 4;
    private static final int C_BORDER = 0xFF00BFFF;
    private static final int C_BORDER_ICE = 0xFF88EEFF;
    private static final int C_GRID = 0x1A00BFFF;
    private static final int C_CASTLE = 0xFFFFD700;
    private static final int C_PLAYER = 0xFF44FF88;
    private static final int C_HEADER_TXT = 0xFF00DFFF;

    public MapScreen() { super(Component.literal("Mapa")); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        boolean ice = ClientData.inNiveria;
        int borderColor = ice ? C_BORDER_ICE : C_BORDER;

        int x = width / 2 - SIZE / 2, y = height / 2 - SIZE / 2;
        int panelW = SIZE + 80;
        int px = width / 2 - panelW / 2;

        // ─── Painel externo ───────────────────────────────────────────────
        g.fillGradient(px - 4, y - 28, px + panelW + 4, y + SIZE + 40, 0xF2020812, 0xF2010508);
        g.renderOutline(px - 4, y - 28, panelW + 8, SIZE + 68, borderColor);
        g.renderOutline(px - 2, y - 26, panelW + 4, SIZE + 64, 0x22FFFFFF);

        // Scanlines
        for (int i = 0; i < SIZE + 68; i += 5) g.fill(px - 4, y - 28 + i, px + panelW + 4, y - 27 + i, 0x06FFFFFF);

        // Header
        g.fill(px - 4, y - 28, px + panelW + 4, y - 8, 0xFF050F1A);
        g.fill(px - 4, y - 8, px + panelW + 4, y - 7, borderColor);
        String mapTitle = ice ? "§b❄ MAPA — NIVÉRIA" : "§b⚡ MAPA — VALDORIA";
        g.drawCenteredString(font, mapTitle, width / 2, y - 22, C_HEADER_TXT);

        // ─── Área do mapa ─────────────────────────────────────────────────
        // Fundo do mapa (cor diferente por dimensão)
        int mapBg = ice ? 0xFF06141E : 0xFF0D1A0D;
        g.fill(x, y, x + SIZE, y + SIZE, mapBg);
        g.renderOutline(x, y, SIZE, SIZE, borderColor);

        // Grid de coordenadas
        for (int i = 1; i < 4; i++) {
            g.fill(x + i * SIZE / 4, y, x + i * SIZE / 4 + 1, y + SIZE, C_GRID);
            g.fill(x, y + i * SIZE / 4, x + SIZE, y + i * SIZE / 4 + 1, C_GRID);
        }

        // Marcadores de bússola
        g.drawCenteredString(font, "§7N", x + SIZE / 2, y + 2, 0xFF556677);
        g.drawCenteredString(font, "§7S", x + SIZE / 2, y + SIZE - 10, 0xFF556677);
        g.drawString(font, "§7O", x + 2, y + SIZE / 2 - 4, 0xFF556677, false);
        g.drawString(font, "§7L", x + SIZE - 8, y + SIZE / 2 - 4, 0xFF556677, false);

        LocalPlayer p = minecraft != null ? minecraft.player : null;
        if (p != null && minecraft.level != null) {
            BlockPos castle = minecraft.level.getSharedSpawnPos();
            int cx = x + SIZE / 2, cy = y + SIZE / 2;

            // Castelo (ponto central - dourado com anel)
            g.fill(cx - 5, cy - 5, cx + 5, cy + 5, 0x44FFD700);
            g.fill(cx - 3, cy - 3, cx + 3, cy + 3, C_CASTLE);
            g.renderOutline(cx - 5, cy - 5, 10, 10, C_CASTLE);
            g.drawString(font, "§6🏰 Castelo", cx + 7, cy - 4, C_CASTLE, false);

            // Jogador (verde pulsante)
            int ppx = clamp(cx + (int)((p.getX() - castle.getX()) / BLOCKS_PER_PX), x + 3, x + SIZE - 4);
            int ppy = clamp(cy + (int)((p.getZ() - castle.getZ()) / BLOCKS_PER_PX), y + 3, y + SIZE - 4);
            g.fill(ppx - 4, ppy - 4, ppx + 4, ppy + 4, 0x4444FF88);
            g.fill(ppx - 2, ppy - 2, ppx + 2, ppy + 2, C_PLAYER);
            g.renderOutline(ppx - 4, ppy - 4, 8, 8, C_PLAYER);

            // Painel lateral direito com legenda
            int lx = x + SIZE + 6, ly = y;
            g.fillGradient(lx, ly, lx + 68, ly + SIZE, 0xFF040E18, 0xFF020609);
            g.renderOutline(lx, ly, 68, SIZE, 0xFF005580);

            // Legenda
            g.drawString(font, "§7LEGENDA", lx + 4, ly + 4, 0xFF334455, false);
            g.fill(lx + 4, ly + 14, lx + 12, ly + 22, C_CASTLE);
            g.drawString(font, "§6Castelo", lx + 16, ly + 15, C_CASTLE, false);
            g.fill(lx + 4, ly + 26, lx + 12, ly + 34, C_PLAYER);
            g.drawString(font, "§aVocê", lx + 16, ly + 27, C_PLAYER, false);

            // Stats rápidos
            g.fill(lx, ly + 46, lx + 68, ly + 47, 0xFF005580);
            g.drawString(font, "§7POSIÇÃO", lx + 4, ly + 50, 0xFF334455, false);
            g.drawString(font, "§fX: §7" + (int)p.getX(), lx + 4, ly + 62, 0xFF7EC8E3, false);
            g.drawString(font, "§fY: §7" + (int)p.getY(), lx + 4, ly + 72, 0xFF7EC8E3, false);
            g.drawString(font, "§fZ: §7" + (int)p.getZ(), lx + 4, ly + 82, 0xFF7EC8E3, false);

            g.fill(lx, ly + 96, lx + 68, ly + 97, 0xFF005580);
            g.drawString(font, "§7SAGA", lx + 4, ly + 100, 0xFF334455, false);
            g.drawString(font, "§fAto §7" + ClientData.act(), lx + 4, ly + 110, 0xFFFFD700, false);
            g.drawString(font, "§f" + ClientData.completed + "§7/101", lx + 4, ly + 120, 0xFF7EC8E3, false);

            if (ClientData.inNiveria) {
                g.fill(lx, ly + 136, lx + 68, ly + 137, 0xFF1166AA);
                g.drawString(font, "§bNIVÉRIA", lx + 4, ly + 140, 0xFF88DDFF, false);
                g.drawString(font, "§b❄ §7" + ClientData.fragmentosGlaciais, lx + 4, ly + 150, 0xFF66CCFF, false);
            }
        }

        // ─── Footer ───────────────────────────────────────────────────────
        int fy = y + SIZE + 8;
        g.fill(px - 4, fy, px + panelW + 4, fy + 22, 0xFF030C16);
        g.fill(px - 4, fy, px + panelW + 4, fy + 1, borderColor);
        g.drawCenteredString(font, "§71 pixel = 4 blocos  |  [M] Fechar",
                width / 2 - 20, fy + 7, 0xFF334455);

        super.render(g, mx, my, pt);
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (KeyMappings.MAP.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }
    @Override public boolean isPauseScreen() { return false; }
}
