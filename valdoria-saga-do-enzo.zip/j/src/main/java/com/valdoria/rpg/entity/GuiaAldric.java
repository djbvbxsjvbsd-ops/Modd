package com.valdoria.rpg.entity;

import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.quest.EspTracker;
import com.valdoria.rpg.quest.GuiaHints;
import com.valdoria.rpg.registry.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

/** Aldric, o Guia: segue o dono, leva até o alvo da missão (boss/local/mob) e ajuda. Invulnerável. */
public class GuiaAldric extends PathfinderMob {
    private UUID owner;
    private float[] dest;
    private int destKind;
    private String destLabel = "";
    private int talkCd = 60, talks = 0, orphan = 0, refreshCd = 0;
    private boolean arrivedSaid = false;

    public GuiaAldric(EntityType<? extends GuiaAldric> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
        this.setPersistenceRequired();
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.36D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    private static boolean isBoss(Entity e) {
        return e instanceof MalacharEntity || e instanceof SenhorGelo || e instanceof DragaoGelo || e instanceof EnzoGlacial;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(2, new GuideGoal(this));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        // ajuda a combater monstros comuns (nunca os bosses)
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false,
                e -> !isBoss(e)));
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }

    private Player ownerPlayer() { return owner == null ? null : level().getPlayerByUUID(owner); }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!level().isClientSide && player instanceof ServerPlayer sp) {
            if (owner == null || owner.equals(sp.getUUID())) {
                owner = sp.getUUID();
                say(sp, GuiaHints.aid(sp));
            } else {
                sp.sendSystemMessage(Component.literal("§6[Aldric] §fEu sirvo a outro Escolhido."));
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    private static void say(Player p, String msg) {
        p.sendSystemMessage(Component.literal("§6[Aldric] §f" + msg));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        // anti-duplicata: só o Aldric mais novo do mesmo dono sobrevive
        if (tickCount % 20 == 0 && owner != null && level() instanceof ServerLevel sl) {
            for (GuiaAldric other : find(sl, owner)) {
                if (other != this && other.getId() > this.getId()) { discard(); return; }
            }
        }
        Player o = ownerPlayer();
        if (!(o instanceof ServerPlayer sp)) {
            if (++orphan > 100) discard();   // dono saiu/mudou de dimensão: o jogo recria o guia
            return;
        }
        orphan = 0;
        if (--refreshCd <= 0) { refreshCd = 40; refreshTarget(sp); }
        if (--talkCd <= 0 && distanceToSqr(sp) < 20 * 20) {
            talkCd = 300;
            talks++;
            if (dest != null && !arrivedSaid) {
                double dx = dest[0] - getX(), dz = dest[2] - getZ();
                say(sp, "Siga-me! " + destLabel + " fica a " + (int) Math.sqrt(dx * dx + dz * dz)
                        + "m (" + GuiaHints.dir(dx, dz) + ")." + (talks % 3 == 0 ? " " + GuiaHints.questLine(sp) : ""));
            } else {
                say(sp, GuiaHints.questLine(sp));
            }
        }
    }

    private void refreshTarget(ServerPlayer sp) {
        EspTracker.Result r = EspTracker.compute(sp);
        float[] best = null; double bd = Double.MAX_VALUE;
        for (float[] p : r.pts()) {
            double d = (p[0] - getX()) * (p[0] - getX()) + (p[2] - getZ()) * (p[2] - getZ());
            if (d < bd) { bd = d; best = p; }
        }
        if (best == null || r.kind() == 0) { dest = null; destKind = 0; arrivedSaid = false; return; }
        if (dest == null || Math.abs(dest[0] - best[0]) > 6 || Math.abs(dest[2] - best[2]) > 6) arrivedSaid = false;
        dest = best; destKind = r.kind(); destLabel = r.label();
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (owner != null) tag.putUUID("Owner", owner);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
    }

    // ---------------- objetivo: seguir / guiar ----------------
    private static class GuideGoal extends Goal {
        private final GuiaAldric g;
        GuideGoal(GuiaAldric g) { this.g = g; setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return g.ownerPlayer() != null; }

        @Override public void tick() {
            Player o = g.ownerPlayer();
            if (o == null) return;
            double d2 = g.distanceToSqr(o);
            if (d2 > 40 * 40) {   // ficou para trás: teleporta
                g.moveTo(o.getX() + 1.5D, o.getY(), o.getZ() + 1.5D, g.getYRot(), 0.0F);
                g.getNavigation().stop();
                return;
            }
            if (g.dest != null && g.destKind != 0) {
                double tx = g.dest[0], tz = g.dest[2];
                double dxz = Math.hypot(tx - g.getX(), tz - g.getZ());
                if (dxz < 4.0D) {                       // chegou
                    g.getNavigation().stop();
                    g.getLookControl().setLookAt(o, 30.0F, 30.0F);
                    if (!g.arrivedSaid && o instanceof ServerPlayer sp) {
                        g.arrivedSaid = true;
                        say(sp, "É aqui! " + g.destLabel + ". Prepare-se, Escolhido.");
                    }
                    return;
                }
                if (d2 > 12 * 12) {                     // espera o jogador alcançar
                    g.getNavigation().stop();
                    g.getLookControl().setLookAt(o, 30.0F, 30.0F);
                    return;
                }
                if (g.tickCount % 10 == 0 || g.getNavigation().isDone()) {
                    double step = Math.min(dxz, 24.0D);
                    g.getNavigation().moveTo(g.getX() + (tx - g.getX()) / dxz * step, g.getY(),
                            g.getZ() + (tz - g.getZ()) / dxz * step, 1.15D);
                }
                return;
            }
            // sem alvo: apenas acompanha
            if (d2 > 6 * 6) {
                if (g.tickCount % 10 == 0 || g.getNavigation().isDone()) g.getNavigation().moveTo(o, 1.2D);
            } else if (d2 < 3 * 3) {
                g.getNavigation().stop();
            }
        }
    }

    // ---------------- controle por jogador ----------------
    private static List<GuiaAldric> find(ServerLevel l, UUID id) {
        List<GuiaAldric> out = new ArrayList<>();
        for (Entity e : l.getAllEntities()) if (e instanceof GuiaAldric g && id.equals(g.owner)) out.add(g);
        return out;
    }

    public static void dismiss(ServerPlayer sp) {
        for (ServerLevel l : sp.getServer().getAllLevels()) for (GuiaAldric g : find(l, sp.getUUID())) g.discard();
    }

    public static void summon(ServerPlayer sp) {
        dismiss(sp);
        ServerLevel lvl = sp.serverLevel();
        GuiaAldric g = ModEntities.GUIA_ALDRIC.get().create(lvl);
        if (g == null) return;
        g.owner = sp.getUUID();
        g.moveTo(sp.getX() + 1.5D, sp.getY(), sp.getZ() + 1.5D, sp.getYRot(), 0.0F);
        lvl.addFreshEntity(g);
        say(sp, "Estou aqui, Escolhido. Clique em mim para ajuda; eu levo você até os bosses.");
    }

    /** @return true se o guia ficou ativo. */
    public static boolean toggle(ServerPlayer sp) {
        boolean on = !PlayerData.root(sp).getBoolean("guia_ativo");
        PlayerData.root(sp).putBoolean("guia_ativo", on);
        if (on) summon(sp); else dismiss(sp);
        return on;
    }

    /** Recria o guia após troca de dimensão/relogin. */
    public static void ensure(ServerPlayer sp) {
        if (!PlayerData.root(sp).getBoolean("guia_ativo")) return;
        long now = sp.serverLevel().getGameTime();
        if (now - PlayerData.root(sp).getLong("guia_spawn") < 200L) return;
        if (find(sp.serverLevel(), sp.getUUID()).isEmpty()) {
            PlayerData.root(sp).putLong("guia_spawn", now);
            summon(sp);
        }
    }
}
