// [NiveriaStructures.java] — CORRIGIDO: usa SPAWN_Y do ChunkGenerator ao invés de hardcoded 20
package com.valdoria.rpg.world;

import com.valdoria.rpg.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Gera as estruturas de Nivéria DENTRO da sala fechada gigante.
 *
 * FIX: Antes usava PISO hardcoded = 20. Agora usa NiveriaChunkGenerator.SPAWN_Y (=15)
 * para que as estruturas fiquem exatamente em cima do piso real gerado.
 */
public final class NiveriaStructures {
    private NiveriaStructures() {}

    // ✅ FIX: usar a constante real do gerador em vez de hardcode 20
    private static final int PISO = NiveriaChunkGenerator.SPAWN_Y; // Y=15

    /** Constrói tudo uma única vez por mundo (marcador = bloco do portal de volta). */
    public static void ensureBuilt(ServerLevel level) {
        if (level.getBlockState(new BlockPos(0, PISO, 0)).is(ModBlocks.PORTAL_NIVERIA.get())) return;
        generateAll(level, new BlockPos(0, PISO, 0));
    }

    public static void generateAll(ServerLevel level, BlockPos playerPos) {
        BlockPos centro = new BlockPos(0, PISO, 0);
        buildVilanevada(level,    centro.offset(80,  0, 0));
        buildTemploGlacial(level, centro.offset(-120, 0, 60));
        buildCasteloNiveria(level, centro.offset(0,   0, 200));

        // Portal de retorno ao Overworld
        BlockPos spawnPortal = new BlockPos(0, PISO - 1, 0);
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) {
            level.setBlock(spawnPortal.offset(x, 0, z), Blocks.BLUE_ICE.defaultBlockState(), 3);
        }
        level.setBlock(spawnPortal.above(1), ModBlocks.PORTAL_NIVERIA.get().defaultBlockState(), 3);
        level.setBlock(spawnPortal.above(2), ModBlocks.PORTAL_NIVERIA.get().defaultBlockState(), 3);

        for (int[] off : new int[][]{{3,0,0},{-3,0,0},{0,0,3},{0,0,-3}}) {
            BlockPos torch = spawnPortal.offset(off[0], 0, off[2]);
            level.setBlock(torch,           Blocks.PACKED_ICE.defaultBlockState(), 3);
            level.setBlock(torch.above(),   Blocks.SEA_LANTERN.defaultBlockState(), 3);
            level.setBlock(torch.above(2),  Blocks.PACKED_ICE.defaultBlockState(), 3);
        }
    }

    private static void p(ServerLevel lvl, BlockPos o, int dx, int dy, int dz, BlockState b) {
        lvl.setBlock(o.offset(dx, dy, dz), b, 3);
    }

    private static void fill(ServerLevel lvl, BlockPos o, int x1, int y1, int z1,
                             int x2, int y2, int z2, BlockState b) {
        for (int x=x1; x<=x2; x++) for (int y=y1; y<=y2; y++) for (int z=z1; z<=z2; z++)
            p(lvl, o, x, y, z, b);
    }

    // ===== VILA NEVADA =====
    public static void buildVilanevada(ServerLevel lvl, BlockPos o) {
        fill(lvl, o, -12, 0, -12, 12, 0, 12, Blocks.SNOW_BLOCK.defaultBlockState());
        buildPoço(lvl, o.offset(0, 1, 0));
        buildCasaNeve(lvl, o.offset(-8, 1, -8));
        buildCasaNeve(lvl, o.offset(6,  1, -8));
        buildCasaNeve(lvl, o.offset(-9, 1,  4));
        buildCasaNeve(lvl, o.offset(6,  1,  4));
        buildCasaForjador(lvl, o.offset(-1, 1,  8));
        for (int[] t : new int[][]{{-12,0},{12,0},{0,-12},{0,12},{-8,8},{8,8}})
            p(lvl, o, t[0], 2, t[1], Blocks.LANTERN.defaultBlockState());
        p(lvl, o, 0, 4, 0, Blocks.BLUE_ICE.defaultBlockState());
        p(lvl, o, 0, 5, 0, Blocks.SEA_LANTERN.defaultBlockState());
    }

    private static void buildCasaNeve(ServerLevel lvl, BlockPos o) {
        for (int y=0; y<3; y++) {
            for (int x=0; x<5; x++) {
                p(lvl, o, x, y, 0, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, x, y, 4, Blocks.SNOW_BLOCK.defaultBlockState());
            }
            for (int z=1; z<4; z++) {
                p(lvl, o, 0, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, 4, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
            }
        }
        for (int x=0; x<5; x++) for (int z=0; z<5; z++)
            p(lvl, o, x, 3, z, Blocks.SPRUCE_PLANKS.defaultBlockState());
        p(lvl, o, 2, 0, 0, Blocks.SPRUCE_DOOR.defaultBlockState());
        p(lvl, o, 1, 1, 0, Blocks.GLASS_PANE.defaultBlockState());
        p(lvl, o, 3, 1, 0, Blocks.GLASS_PANE.defaultBlockState());
        p(lvl, o, 1, 0, 2, Blocks.RED_BED.defaultBlockState());
        p(lvl, o, 3, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 2, 2, 2, Blocks.TORCH.defaultBlockState());
    }

    private static void buildCasaForjador(ServerLevel lvl, BlockPos o) {
        for (int y=0; y<4; y++) {
            for (int x=0; x<7; x++) {
                p(lvl, o, x, y, 0, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, x, y, 4, Blocks.SNOW_BLOCK.defaultBlockState());
            }
            for (int z=1; z<4; z++) {
                p(lvl, o, 0, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, 6, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
            }
        }
        for (int x=0; x<7; x++) for (int z=0; z<5; z++)
            p(lvl, o, x, 4, z, Blocks.SPRUCE_PLANKS.defaultBlockState());
        p(lvl, o, 3, 0, 0, Blocks.SPRUCE_DOOR.defaultBlockState());
        p(lvl, o, 1, 0, 2, Blocks.FURNACE.defaultBlockState());
        p(lvl, o, 2, 0, 2, Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl, o, 3, 0, 2, Blocks.ANVIL.defaultBlockState());
        p(lvl, o, 4, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 5, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 3, 3, 2, Blocks.TORCH.defaultBlockState());
    }

    private static void buildPoço(ServerLevel lvl, BlockPos o) {
        for (int x=-1; x<=1; x++) for (int z=-1; z<=1; z++) {
            if (x==0&&z==0) { p(lvl,o,0,0,0,Blocks.WATER.defaultBlockState()); continue; }
            p(lvl,o,x,0,z,Blocks.STONE_BRICKS.defaultBlockState());
            p(lvl,o,x,1,z,Blocks.STONE_BRICKS.defaultBlockState());
        }
        p(lvl,o,-1,2,0,Blocks.SPRUCE_FENCE.defaultBlockState());
        p(lvl,o, 1,2,0,Blocks.SPRUCE_FENCE.defaultBlockState());
        p(lvl,o, 0,3,0,Blocks.OAK_SLAB.defaultBlockState());
    }

    // ===== TEMPLO GLACIAL =====
    public static void buildTemploGlacial(ServerLevel lvl, BlockPos o) {
        fill(lvl,o,-10,0,-10,10,0,10,Blocks.BLUE_ICE.defaultBlockState());
        for (int y=1; y<=6; y++) {
            for (int x=-10; x<=10; x++) {
                p(lvl,o,x,y,-10,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,y, 10,Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z=-9; z<=9; z++) {
                p(lvl,o,-10,y,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o, 10,y,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        fill(lvl,o,-10,7,-10,10,7,10,Blocks.PACKED_ICE.defaultBlockState());
        for (int y=1; y<=4; y++) for (int x=-2; x<=2; x++)
            p(lvl,o,x,y,-10,Blocks.AIR.defaultBlockState());
        for (int[] c : new int[][]{{-5,5},{5,5},{-5,-5},{5,-5}}) {
            for (int cy=1; cy<=3; cy++) p(lvl,o,c[0],cy,c[1],Blocks.BLUE_ICE.defaultBlockState());
            p(lvl,o,c[0],4,c[1],Blocks.BEACON.defaultBlockState());
        }
        p(lvl,o,0,1,0,Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        p(lvl,o,0,2,0,Blocks.ENCHANTING_TABLE.defaultBlockState());
        for (int bx=-8; bx<=-5; bx++) {
            p(lvl,o,bx,1,7,Blocks.BOOKSHELF.defaultBlockState());
            p(lvl,o,bx,2,7,Blocks.BOOKSHELF.defaultBlockState());
        }
        p(lvl,o,-6,1,6,Blocks.CHEST.defaultBlockState());
        for (int[] c : new int[][]{{-10,-10},{10,-10},{-10,10},{10,10}}) {
            for (int ty=7; ty<=12; ty++) p(lvl,o,c[0],ty,c[1],Blocks.PACKED_ICE.defaultBlockState());
            p(lvl,o,c[0],13,c[1],Blocks.BLUE_ICE.defaultBlockState());
        }
        p(lvl,o,7,1,-7,Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl,o,8,1,-7,Blocks.ANVIL.defaultBlockState());
        p(lvl,o,7,1,-8,Blocks.BLUE_ICE.defaultBlockState());
        p(lvl,o,8,1,-8,Blocks.CHEST.defaultBlockState());
        for (int[] t : new int[][]{{-9,0},{9,0},{0,-9},{0,9},{-7,-7},{7,-7},{-7,7},{7,7}})
            p(lvl,o,t[0],3,t[1],Blocks.LANTERN.defaultBlockState());
    }

    // ===== CASTELO DE NIVÉRIA =====
    public static void buildCasteloNiveria(ServerLevel lvl, BlockPos o) {
        for (int x=-27; x<=27; x++) for (int z=-27; z<=27; z++)
            if (Math.abs(x)>=24||Math.abs(z)>=24) {
                p(lvl,o,x,-1,z,Blocks.BLUE_ICE.defaultBlockState());
                p(lvl,o,x,-2,z,Blocks.BLUE_ICE.defaultBlockState());
            }
        fill(lvl,o,-25,0,-25,25,0,25,Blocks.BLUE_ICE.defaultBlockState());
        for (int y=1; y<=8; y++) {
            for (int x=-25; x<=25; x++) {
                p(lvl,o,x,y,-25,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,y, 25,Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z=-24; z<=24; z++) {
                p(lvl,o,-25,y,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o, 25,y,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        for (int x=-25; x<=25; x+=2) {
            p(lvl,o,x,9,-25,Blocks.PACKED_ICE.defaultBlockState());
            p(lvl,o,x,9, 25,Blocks.PACKED_ICE.defaultBlockState());
        }
        for (int z=-25; z<=25; z+=2) {
            p(lvl,o,-25,9,z,Blocks.PACKED_ICE.defaultBlockState());
            p(lvl,o, 25,9,z,Blocks.PACKED_ICE.defaultBlockState());
        }
        for (int[] tc : new int[][]{{-25,-25},{25,-25},{-25,25},{25,25},{0,-25},{0,25},{-25,0},{25,0}})
            buildTorreGlacial(lvl, o, tc[0], tc[1]);
        for (int y=1; y<=5; y++) for (int px=-3; px<=3; px++)
            p(lvl,o,px,y,-25,Blocks.AIR.defaultBlockState());
        for (int px=-3; px<=3; px++) p(lvl,o,px,6,-25,Blocks.BLUE_ICE.defaultBlockState());
        for (int y=1; y<=5; y++) {
            p(lvl,o,-3,y,-25,Blocks.IRON_BARS.defaultBlockState());
            p(lvl,o, 3,y,-25,Blocks.IRON_BARS.defaultBlockState());
        }
        fill(lvl,o,-2,1,-2,2,1,2,Blocks.ICE.defaultBlockState());
        p(lvl,o,0,2,0,Blocks.BLUE_ICE.defaultBlockState());
        p(lvl,o,0,3,0,Blocks.BEACON.defaultBlockState());
        fill(lvl,o,-8,1,8,8,1,16,Blocks.BLUE_ICE.defaultBlockState());
        for (int y=1; y<=8; y++) {
            for (int x=-8; x<=8; x++) {
                p(lvl,o,x,y, 8,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,y,16,Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z=9; z<=15; z++) {
                p(lvl,o,-8,y,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o, 8,y,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        fill(lvl,o,-8,9,8,8,9,16,Blocks.PACKED_ICE.defaultBlockState());
        for (int tx=-1; tx<=1; tx++) {
            p(lvl,o,tx,1,15,Blocks.BLUE_ICE.defaultBlockState());
            p(lvl,o,tx,2,15,Blocks.BLUE_ICE.defaultBlockState());
        }
        p(lvl,o,0,3,15,Blocks.BLUE_ICE.defaultBlockState());
        p(lvl,o,0,4,15,Blocks.BEACON.defaultBlockState());
        for (int tz=9; tz<=14; tz++) p(lvl,o,0,1,tz,Blocks.BLUE_CARPET.defaultBlockState());
        p(lvl,o,2,1,15,Blocks.CHEST.defaultBlockState());
        buildSalaArsenal(lvl, o.offset(-18, 1, -10));
        buildSalaArsenal(lvl, o.offset( 15, 1, -10));
        for (int lx=-22; lx<=22; lx+=7) {
            p(lvl,o,lx,8,-24,Blocks.LANTERN.defaultBlockState());
            p(lvl,o,lx,8, 24,Blocks.LANTERN.defaultBlockState());
        }
        for (int lz=-22; lz<=22; lz+=7) {
            p(lvl,o,-24,8,lz,Blocks.LANTERN.defaultBlockState());
            p(lvl,o, 24,8,lz,Blocks.LANTERN.defaultBlockState());
        }
        buildArena(lvl, o.offset(0, 21, 18));
    }

    private static void buildTorreGlacial(ServerLevel lvl, BlockPos base, int tx, int tz) {
        int sx = tx<0?-1:1, sz = tz<0?-1:1;
        for (int y=1; y<=20; y++)
            for (int dx=0; dx<=2; dx++) for (int dz=0; dz<=2; dz++)
                p(lvl,base,tx+dx*sx,y,tz+dz*sz,Blocks.PACKED_ICE.defaultBlockState());
        for (int y=21; y<=24; y++) p(lvl,base,tx,y,tz,Blocks.BLUE_ICE.defaultBlockState());
        p(lvl,base,tx,25,tz,Blocks.BEACON.defaultBlockState());
        p(lvl,base,tx, 3,tz,Blocks.WALL_TORCH.defaultBlockState());
        p(lvl,base,tx,10,tz,Blocks.WALL_TORCH.defaultBlockState());
    }

    private static void buildSalaArsenal(ServerLevel lvl, BlockPos o) {
        for (int y=0; y<=4; y++) {
            for (int x=0; x<6; x++) {
                p(lvl,o,x,y,0,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,y,5,Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z=1; z<5; z++) {
                p(lvl,o,0,y,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,5,y,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        fill(lvl,o,0,5,0,5,5,5,Blocks.PACKED_ICE.defaultBlockState());
        p(lvl,o,2,0,0,Blocks.SPRUCE_DOOR.defaultBlockState());
        p(lvl,o,1,0,2,Blocks.CHEST.defaultBlockState());
        p(lvl,o,2,0,2,Blocks.CHEST.defaultBlockState());
        p(lvl,o,3,0,2,Blocks.ANVIL.defaultBlockState());
        p(lvl,o,4,0,2,Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl,o,2,3,2,Blocks.TORCH.defaultBlockState());
    }

    private static void buildArena(ServerLevel lvl, BlockPos o) {
        for (int x=-7; x<=7; x++) for (int z=-7; z<=7; z++)
            if (x*x+z*z<=49) p(lvl,o,x,0,z,Blocks.BLUE_ICE.defaultBlockState());
        for (int x=-7; x<=7; x++) for (int z=-7; z<=7; z++)
            if (x*x+z*z>=44&&x*x+z*z<=50) {
                p(lvl,o,x,1,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,2,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        p(lvl,o,0,1,0,Blocks.IRON_BLOCK.defaultBlockState());
        p(lvl,o,0,2,0,Blocks.BEACON.defaultBlockState());
        for (int[] c : new int[][]{{-5,-5},{5,-5},{-5,5},{5,5}}) {
            for (int py=1; py<=5; py++) p(lvl,o,c[0],py,c[1],Blocks.BLUE_ICE.defaultBlockState());
            p(lvl,o,c[0],5,c[1],Blocks.LANTERN.defaultBlockState());
        }
    }
}
