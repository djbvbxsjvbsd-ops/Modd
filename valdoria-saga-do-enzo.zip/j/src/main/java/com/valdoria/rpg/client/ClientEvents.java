// [ClientEvents.java] — Teclados de classe, Redemoinho, Nivéria overlay e ESP de quest
package com.valdoria.rpg.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.client.screen.ClassScreen;
import com.valdoria.rpg.client.screen.MapScreen;
import com.valdoria.rpg.client.screen.ProfileScreen;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.network.WhirlpoolPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, value = Dist.CLIENT)
public class ClientEvents {
    private static int coldFlicker = 0;

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        while (KeyMappings.PROFILE.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new ProfileScreen());
        }
        while (KeyMappings.MAP.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new MapScreen());
        }
        while (KeyMappings.HUD.consumeClick()) {
            ClientData.hudVisible = !ClientData.hudVisible;
        }
        while (KeyMappings.CLASS_SCR.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new ClassScreen());
        }
        while (KeyMappings.WHIRLPOOL.consumeClick()) {
            if (mc.player != null && ClientData.isIceKing() && mc.screen == null) {
                ModNetwork.INSTANCE.sendToServer(new WhirlpoolPacket());
            }
        }
        coldFlicker++;
    }

    @SubscribeEvent
    public static void fog(ViewportEvent.ComputeFogColor e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (ClientData.completed >= 20 && ClientData.completed < 49 && mc.level.dimension() == Level.OVERWORLD) {
            e.setRed(0.70F); e.setGreen(0.05F); e.setBlue(0.05F);
        }
        if (ClientData.inNiveria) {
            e.setRed(0.60F); e.setGreen(0.78F); e.setBlue(0.95F);
        }
    }

    @SubscribeEvent
    public static void renderOverlay(RenderGuiOverlayEvent.Post e) {
        if (!ClientData.inNiveria) return;
        if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        boolean isKing = ClientData.isIceKing();
        int alpha = isKing ? 0x14 : 0x22;
        boolean visible = (coldFlicker / 20) % 2 == 0;
        if (visible && !isKing) {
            e.getGuiGraphics().fill(0, 0, w, h, (alpha << 24) | 0x006680);
            e.getGuiGraphics().drawCenteredString(mc.font, "§b❄ FRIO EXTREMO ❄", w / 2, h / 2 - 60, 0xFF88CCFF);
        }
        if (isKing && visible) {
            e.getGuiGraphics().drawCenteredString(mc.font, "§b❄ Rei do Gelo — 40% resist", w / 2, h / 2 - 60, 0xFF44CCFF);
        }
    }

    // =========================================================================
    // ESP — bounding-box colorida ao redor do alvo da quest ativa
    // =========================================================================
    @SubscribeEvent
    public static void renderLevel(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        if (ClientData.espPts.isEmpty() && ClientData.questTargetType != 2) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        QuestEsp.render(e.getPoseStack(), buf);
        buf.endBatch(EspRenderTypes.ESP_LINES);   // RenderType próprio, sem depth test
    }

    /** Distância até o alvo da missão (topo da tela). */
    @SubscribeEvent
    public static void espHud(RenderGuiOverlayEvent.Post e) {
        if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || ClientData.espKind == 0) return;
        String txt;
        if (ClientData.espPts.isEmpty()) {
            txt = "§7◆ " + ClientData.espLabel + " — sem alvo carregado por perto";
        } else {
            double best = Double.MAX_VALUE;
            for (float[] p : ClientData.espPts) {
                double dx = p[0] - mc.player.getX(), dy = p[1] - mc.player.getY(), dz = p[2] - mc.player.getZ();
                best = Math.min(best, Math.sqrt(dx * dx + dy * dy + dz * dz));
            }
            txt = "§e◆ " + ClientData.espLabel + " §f" + (int) best + "m";
        }
        e.getGuiGraphics().drawCenteredString(mc.font, txt, mc.getWindow().getGuiScaledWidth() / 2, 6, 0xFFFFFFFF);
    }
}
