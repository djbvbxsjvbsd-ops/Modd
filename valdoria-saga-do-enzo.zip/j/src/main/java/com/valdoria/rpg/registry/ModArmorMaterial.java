package com.valdoria.rpg.registry;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

public enum ModArmorMaterial implements ArmorMaterial {
    VALDORIA;

    private static final int[] DURABILITY = {13, 15, 16, 11};
    private static final int[] DEFENSE = {4, 9, 7, 4};

    @Override public int getDurabilityForType(ArmorItem.Type type) { return DURABILITY[type.ordinal()] * 45; }
    @Override public int getDefenseForType(ArmorItem.Type type) { return DEFENSE[type.ordinal()]; }
    @Override public int getEnchantmentValue() { return 20; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_NETHERITE; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.GUARDIAN_ESSENCE.get()); }
    // textura própria: textures/models/armor/valdoria_layer_*.png
    @Override public String getName() { return "valdorianrpg:valdoria"; }
    @Override public float getToughness() { return 4.0F; }
    @Override public float getKnockbackResistance() { return 0.2F; }
}
