package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.client.KeyMappings;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

/** Mapa simples: castelo (spawn do mundo) e posição do jogador. 1 pixel = 4 blocos. */
public class MapScreen extends Screen {
    private static final int SIZE = 200;
    private static final int BLOCKS_PER_PX = 4;

    public MapScreen() {
        super(Component.literal("Mapa de Valdoria"));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x = width / 2 - SIZE / 2, y = height / 2 - SIZE / 2;
        g.fill(x, y, x + SIZE, y + SIZE, 0xFF2B3A22);
        g.renderOutline(x, y, SIZE, SIZE, 0xFFB8860B);
        for (int i = 1; i < 4; i++) {
            g.fill(x + i * SIZE / 4, y, x + i * SIZE / 4 + 1, y + SIZE, 0x33FFFFFF);
            g.fill(x, y + i * SIZE / 4, x + SIZE, y + i * SIZE / 4 + 1, 0x33FFFFFF);
        }
        g.drawCenteredString(font, "§6§lMAPA DE VALDORIA", width / 2, y - 14, 0xFFFFFF);

        LocalPlayer p = minecraft.player;
        if (p != null && minecraft.level != null) {
            BlockPos castle = minecraft.level.getSharedSpawnPos();
            int cx = x + SIZE / 2, cy = y + SIZE / 2;
            g.fill(cx - 3, cy - 3, cx + 3, cy + 3, 0xFFFFD54F);
            g.drawString(font, "Castelo", cx + 6, cy - 4, 0xFFD54F, false);

            int px = clamp(cx + (int) ((p.getX() - castle.getX()) / BLOCKS_PER_PX), x + 2, x + SIZE - 3);
            int py = clamp(cy + (int) ((p.getZ() - castle.getZ()) / BLOCKS_PER_PX), y + 2, y + SIZE - 3);
            g.fill(px - 2, py - 2, px + 2, py + 2, 0xFF66FF66);
            g.drawCenteredString(font, String.format("Você: %d, %d, %d  |  %s",
                    (int) p.getX(), (int) p.getY(), (int) p.getZ(), minecraft.level.dimension().location().getPath()),
                    width / 2, y + SIZE + 8, 0xFFFFFF);
        }
        super.render(g, mx, my, pt);
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (KeyMappings.MAP.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
