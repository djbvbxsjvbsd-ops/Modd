package com.valdoria.rpg.network;

import com.valdoria.rpg.client.ClientData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public class SyncDataPacket {
    private final int faction, completed;
    private final float mana, maxMana;

    public SyncDataPacket(int faction, int completed, float mana, float maxMana) {
        this.faction = faction; this.completed = completed; this.mana = mana; this.maxMana = maxMana;
    }

    public static void encode(SyncDataPacket m, FriendlyByteBuf buf) {
        buf.writeInt(m.faction); buf.writeInt(m.completed); buf.writeFloat(m.mana); buf.writeFloat(m.maxMana);
    }

    public static SyncDataPacket decode(FriendlyByteBuf buf) {
        return new SyncDataPacket(buf.readInt(), buf.readInt(), buf.readFloat(), buf.readFloat());
    }

    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientData.update(faction, completed, mana, maxMana));
    }
}
