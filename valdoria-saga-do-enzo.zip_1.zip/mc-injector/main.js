const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { execSync } = require('child_process');

function createWindow() {
  const win = new BrowserWindow({
    width: 520,
    height: 620,
    resizable: false,
    frame: false,
    transparent: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    icon: path.join(__dirname, 'assets', 'icon.ico')
  });
  win.loadFile('index.html');
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

// ── Fechar/minimizar janela ──
ipcMain.on('close-app', () => app.quit());
ipcMain.on('minimize-app', (e) => BrowserWindow.fromWebContents(e.sender).minimize());

// ── Leitura do PC ──
ipcMain.handle('get-system-info', async () => {
  const info = {
    ram: Math.round(os.totalmem() / 1024 / 1024 / 1024),
    cpus: os.cpus().length,
    cpuModel: os.cpus()[0]?.model || 'Desconhecido',
    platform: os.platform(),
    arch: os.arch()
  };

  // Tentar pegar GPU no Windows
  try {
    const gpu = execSync('wmic path win32_VideoController get name /value', { timeout: 3000 })
      .toString().match(/Name=(.+)/)?.[1]?.trim() || 'Desconhecida';
    info.gpu = gpu;
  } catch {
    info.gpu = 'Não detectada';
  }

  return info;
});

// ── Detectar pasta do Minecraft ──
ipcMain.handle('get-mc-paths', async () => {
  const home = os.homedir();
  const paths = {
    java: path.join(home, 'AppData', 'Roaming', '.minecraft'),
    bedrock: path.join(home, 'AppData', 'Local', 'Packages',
      'Microsoft.MinecraftUWP_8wekyb3d8bbwe', 'LocalState', 'games', 'com.mojang')
  };
  return {
    java: fs.existsSync(paths.java) ? paths.java : null,
    bedrock: fs.existsSync(paths.bedrock) ? paths.bedrock : null
  };
});

// ── Injetar mod/shader ──
ipcMain.handle('inject', async (e, { type, edition, mcPath }) => {
  try {
    const AdmZip = (() => {
      try { return require('adm-zip'); } catch { return null; }
    })();

    const assetsDir = path.join(process.resourcesPath || __dirname, 'assets');

    const fileMap = {
      mod_valdoria: path.join(assetsDir, 'valdorianrpg-jar.zip'),
      shader_bsl: path.join(assetsDir, 'BSL_v10_1_8.zip'),
      shader_complementary: path.join(assetsDir, 'ComplementaryUnbound_r5_9_3.zip')
    };

    const srcZip = fileMap[type];
    if (!srcZip || !fs.existsSync(srcZip)) return { ok: false, msg: 'Arquivo não encontrado nos assets.' };

    if (edition === 'java') {
      let destDir;
      if (type === 'mod_valdoria') {
        destDir = path.join(mcPath, 'mods');
      } else {
        destDir = path.join(mcPath, 'shaderpacks');
      }
      fs.mkdirSync(destDir, { recursive: true });

      if (type === 'mod_valdoria') {
        // extrair o .jar de dentro do zip
        if (AdmZip) {
          const zip = new AdmZip(srcZip);
          const entry = zip.getEntries().find(e => e.entryName.endsWith('.jar'));
          if (entry) {
            zip.extractEntryTo(entry, destDir, false, true);
            return { ok: true, msg: `Mod instalado em:\n${destDir}` };
          }
        }
        // fallback: copiar zip inteiro
        fs.copyFileSync(srcZip, path.join(destDir, path.basename(srcZip)));
        return { ok: true, msg: `Arquivo copiado para:\n${destDir}` };
      } else {
        // shaders: copiar o zip direto para shaderpacks
        const dest = path.join(destDir, path.basename(srcZip));
        fs.copyFileSync(srcZip, dest);
        return { ok: true, msg: `Shader instalado em:\n${destDir}` };
      }
    }

    return { ok: false, msg: 'Mods/shaders não são suportados no Bedrock.' };
  } catch (err) {
    return { ok: false, msg: err.message };
  }
});
